import SymptomTracker from '../SymptomTracker';

export default function SymptomTrackerExample() {
  return <SymptomTracker />;
}
