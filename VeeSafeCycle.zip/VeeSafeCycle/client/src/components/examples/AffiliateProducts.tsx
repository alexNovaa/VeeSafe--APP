import AffiliateProducts from '../AffiliateProducts';

export default function AffiliateProductsExample() {
  return <AffiliateProducts />;
}
