import CycleInputForm from '../CycleInputForm';

export default function CycleInputFormExample() {
  return (
    <CycleInputForm
      onSubmit={(data) => console.log('Form submitted:', data)}
      initialData={{
        lastPeriodDate: '2025-10-15',
        cycleLength: 28,
        periodDuration: 5,
      }}
    />
  );
}
