import OvulationPrediction from '../OvulationPrediction';

export default function OvulationPredictionExample() {
  return (
    <OvulationPrediction
      nextOvulationDate="2025-11-12"
      daysUntilOvulation={8}
      currentCycleDay={14}
      cycleLength={28}
      fertileWindowStart="2025-11-10"
      fertileWindowEnd="2025-11-15"
    />
  );
}
