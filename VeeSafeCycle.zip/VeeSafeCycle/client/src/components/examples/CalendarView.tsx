import CalendarView from '../CalendarView';

export default function CalendarViewExample() {
  const generateCalendarDays = () => {
    const today = new Date(2025, 10, 4);
    const firstDay = new Date(2025, 10, 1);
    const lastDay = new Date(2025, 10, 30);
    
    const days = [];
    const startDay = firstDay.getDay();
    
    for (let i = 0; i < startDay; i++) {
      const prevDate = new Date(2025, 9, 31 - startDay + i + 1);
      days.push({
        date: prevDate,
        dayNumber: prevDate.getDate(),
        isPeriod: false,
        isFertile: false,
        isOvulation: false,
        isToday: false,
        isCurrentMonth: false,
      });
    }
    
    for (let i = 1; i <= 30; i++) {
      const date = new Date(2025, 10, i);
      days.push({
        date,
        dayNumber: i,
        isPeriod: i >= 1 && i <= 5,
        isFertile: i >= 10 && i <= 15,
        isOvulation: i === 12,
        isToday: i === 4,
        isCurrentMonth: true,
      });
    }
    
    return days;
  };

  return (
    <CalendarView
      days={generateCalendarDays()}
      currentMonth="November 2025"
    />
  );
}
