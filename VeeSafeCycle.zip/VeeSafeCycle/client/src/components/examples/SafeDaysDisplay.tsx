import SafeDaysDisplay from '../SafeDaysDisplay';

export default function SafeDaysDisplayExample() {
  return (
    <SafeDaysDisplay
      isSafePeriod={true}
      daysUntilFertileWindow={6}
      nextPeriodDate="2025-11-28"
    />
  );
}
