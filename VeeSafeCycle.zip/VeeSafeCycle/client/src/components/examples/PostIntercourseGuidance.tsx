import PostIntercourseGuidance from '../PostIntercourseGuidance';

export default function PostIntercourseGuidanceExample() {
  return <PostIntercourseGuidance isInFertileWindow={true} />;
}
