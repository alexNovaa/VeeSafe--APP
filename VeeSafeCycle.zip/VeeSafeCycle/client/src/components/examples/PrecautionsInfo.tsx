import PrecautionsInfo from '../PrecautionsInfo';

export default function PrecautionsInfoExample() {
  return <PrecautionsInfo />;
}
