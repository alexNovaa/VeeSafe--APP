import AnonymousIdCard from '../AnonymousIdCard';

export default function AnonymousIdCardExample() {
  return <AnonymousIdCard userId="a1b2c3d4-e5f6-7890-abcd-ef1234567890" />;
}
