import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, Package } from "lucide-react";

interface Product {
  id: string;
  name: string;
  description: string;
  category: string;
  affiliateLink: string;
}

interface AffiliateProductsProps {
  products?: Product[];
}

export default function AffiliateProducts({ products = [] }: AffiliateProductsProps) {
  const defaultProducts: Product[] = [
    {
      id: "1",
      name: "Emergency Contraception",
      description: "Plan B and other emergency contraceptive options",
      category: "Contraception",
      affiliateLink: "#",
    },
    {
      id: "2",
      name: "Pregnancy Tests",
      description: "Early detection home pregnancy test kits",
      category: "Testing",
      affiliateLink: "#",
    },
    {
      id: "3",
      name: "Ovulation Test Strips",
      description: "Accurate ovulation predictor kits",
      category: "Testing",
      affiliateLink: "#",
    },
    {
      id: "4",
      name: "Menstrual Care Products",
      description: "Pads, tampons, menstrual cups, and more",
      category: "Menstrual Care",
      affiliateLink: "#",
    },
  ];

  const displayProducts = products.length > 0 ? products : defaultProducts;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Package className="w-5 h-5 text-primary" />
          <CardTitle>Recommended Products</CardTitle>
        </div>
        <CardDescription>
          Products that may help with your sexual health needs
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {displayProducts.map((product) => (
            <div
              key={product.id}
              className="p-4 border rounded-md hover-elevate space-y-3"
              data-testid={`product-card-${product.id}`}
            >
              <div className="space-y-1">
                <div className="flex items-start justify-between gap-2">
                  <h4 className="font-medium">{product.name}</h4>
                  <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                    {product.category}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">
                  {product.description}
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="w-full gap-2"
                asChild
                data-testid={`button-view-product-${product.id}`}
              >
                <a href={product.affiliateLink} target="_blank" rel="noopener noreferrer">
                  View Product
                  <ExternalLink className="w-3 h-3" />
                </a>
              </Button>
            </div>
          ))}
        </div>
        <div className="mt-4 p-3 bg-muted rounded-md">
          <p className="text-xs text-muted-foreground">
            <strong>Disclaimer:</strong> These are affiliate links. We may earn a commission 
            from purchases made through these links at no extra cost to you.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
