import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, Clock, ShieldCheck } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

interface PostIntercourseGuidanceProps {
  isInFertileWindow: boolean;
}

export default function PostIntercourseGuidance({ isInFertileWindow }: PostIntercourseGuidanceProps) {
  const [selectedScenario, setSelectedScenario] = useState<string>("");

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <AlertCircle className="w-5 h-5 text-primary" />
          <CardTitle>Post-Intercourse Guidance</CardTitle>
        </div>
        <CardDescription>
          What to do if you've had unprotected intercourse
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <p className="text-sm font-medium">Select your situation:</p>
          <div className="grid gap-2">
            <Button
              variant={selectedScenario === "within-72h" ? "default" : "outline"}
              className="justify-start h-auto py-3 px-4"
              onClick={() => setSelectedScenario("within-72h")}
              data-testid="button-scenario-72h"
            >
              <div className="text-left">
                <div className="font-medium">Within 72 hours (3 days)</div>
                <div className="text-xs text-muted-foreground">Unprotected intercourse happened recently</div>
              </div>
            </Button>
            <Button
              variant={selectedScenario === "72h-5days" ? "default" : "outline"}
              className="justify-start h-auto py-3 px-4"
              onClick={() => setSelectedScenario("72h-5days")}
              data-testid="button-scenario-5days"
            >
              <div className="text-left">
                <div className="font-medium">3-5 days ago</div>
                <div className="text-xs text-muted-foreground">Still within emergency contraception window</div>
              </div>
            </Button>
            <Button
              variant={selectedScenario === "over-5days" ? "default" : "outline"}
              className="justify-start h-auto py-3 px-4"
              onClick={() => setSelectedScenario("over-5days")}
              data-testid="button-scenario-over-5days"
            >
              <div className="text-left">
                <div className="font-medium">More than 5 days ago</div>
                <div className="text-xs text-muted-foreground">Past emergency contraception window</div>
              </div>
            </Button>
          </div>
        </div>

        {selectedScenario && (
          <div className="space-y-4 pt-4 border-t">
            {selectedScenario === "within-72h" && (
              <div className="space-y-3">
                <div className="flex items-start gap-3 p-4 bg-chart-3/10 rounded-md border border-chart-3/20">
                  <Clock className="w-5 h-5 text-chart-3 mt-0.5 flex-shrink-0" />
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Time-Sensitive Actions</p>
                    <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                      <li>Consider emergency contraception (Plan B, ella, or copper IUD)</li>
                      <li>Most effective when taken as soon as possible</li>
                      <li>Available over-the-counter at pharmacies</li>
                    </ul>
                  </div>
                </div>
                {isInFertileWindow && (
                  <div className="flex items-start gap-3 p-4 bg-destructive/10 rounded-md border border-destructive/20">
                    <AlertCircle className="w-5 h-5 text-destructive mt-0.5 flex-shrink-0" />
                    <p className="text-sm">
                      <strong>Important:</strong> You are currently in your fertile window. 
                      Emergency contraception is strongly recommended.
                    </p>
                  </div>
                )}
              </div>
            )}

            {selectedScenario === "72h-5days" && (
              <div className="space-y-3">
                <div className="flex items-start gap-3 p-4 bg-chart-3/10 rounded-md border border-chart-3/20">
                  <ShieldCheck className="w-5 h-5 text-chart-3 mt-0.5 flex-shrink-0" />
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Options Available</p>
                    <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                      <li>ella (ulipristal acetate) - effective up to 5 days</li>
                      <li>Copper IUD - can be inserted up to 5 days after</li>
                      <li>Consult with a healthcare provider immediately</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {selectedScenario === "over-5days" && (
              <div className="space-y-3">
                <div className="flex items-start gap-3 p-4 bg-muted rounded-md">
                  <AlertCircle className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Next Steps</p>
                    <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                      <li>Emergency contraception is no longer effective</li>
                      <li>Wait for expected period or take pregnancy test</li>
                      <li>Pregnancy tests are most accurate 1-2 weeks after missed period</li>
                      <li>Consider consulting with a healthcare provider</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="symptoms">
                <AccordionTrigger data-testid="accordion-symptoms">
                  Signs to Watch For
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p className="font-medium text-foreground">Early pregnancy signs (2-4 weeks):</p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>Missed period</li>
                      <li>Breast tenderness</li>
                      <li>Nausea or morning sickness</li>
                      <li>Fatigue</li>
                      <li>Frequent urination</li>
                    </ul>
                  </div>
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="testing">
                <AccordionTrigger data-testid="accordion-testing">
                  When to Take a Pregnancy Test
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <ul className="list-disc list-inside space-y-1">
                      <li>Wait at least 1-2 weeks after missed period for accurate results</li>
                      <li>Take test in the morning for best results</li>
                      <li>Follow test instructions carefully</li>
                      <li>If negative but still no period, test again in a few days</li>
                    </ul>
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        )}

        <div className="flex items-start gap-2 p-3 bg-muted rounded-md">
          <AlertCircle className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
          <p className="text-xs text-muted-foreground">
            This guidance is for informational purposes only. Always consult with a healthcare 
            professional for personalized medical advice.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
