import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, ExternalLink } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export default function PrecautionsInfo() {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-primary" />
          <CardTitle>Precautions & Resources</CardTitle>
        </div>
        <CardDescription>
          Important information about protection and sexual health
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="contraception">
            <AccordionTrigger data-testid="accordion-contraception">
              Contraception Methods
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-3 text-sm">
                <div className="space-y-1">
                  <p className="font-medium">Barrier Methods</p>
                  <ul className="list-disc list-inside text-muted-foreground space-y-1 ml-2">
                    <li>Condoms (male and female) - Also prevent STIs</li>
                    <li>Diaphragm or cervical cap</li>
                  </ul>
                </div>
                <div className="space-y-1">
                  <p className="font-medium">Hormonal Methods</p>
                  <ul className="list-disc list-inside text-muted-foreground space-y-1 ml-2">
                    <li>Birth control pills</li>
                    <li>Patch, ring, or injection</li>
                    <li>IUD (hormonal or copper)</li>
                    <li>Implant</li>
                  </ul>
                </div>
                <div className="space-y-1">
                  <p className="font-medium">Emergency Contraception</p>
                  <ul className="list-disc list-inside text-muted-foreground space-y-1 ml-2">
                    <li>Plan B (levonorgestrel) - up to 72 hours</li>
                    <li>ella (ulipristal) - up to 5 days</li>
                    <li>Copper IUD - up to 5 days</li>
                  </ul>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="sti-prevention">
            <AccordionTrigger data-testid="accordion-sti">
              STI Prevention
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-3 text-sm">
                <p className="text-muted-foreground">
                  Sexually transmitted infections (STIs) can be prevented through:
                </p>
                <ul className="list-disc list-inside text-muted-foreground space-y-1 ml-2">
                  <li>Using condoms consistently and correctly</li>
                  <li>Regular STI testing (every 3-6 months if sexually active)</li>
                  <li>Open communication with partners about sexual health</li>
                  <li>Getting vaccinated (HPV, Hepatitis B)</li>
                  <li>Limiting number of sexual partners</li>
                </ul>
                <div className="p-3 bg-muted rounded-md mt-3">
                  <p className="text-xs">
                    <strong>Note:</strong> Only barrier methods (condoms) protect against both 
                    pregnancy and STIs. All other contraceptive methods only prevent pregnancy.
                  </p>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="pregnancy-signs">
            <AccordionTrigger data-testid="accordion-pregnancy-signs">
              Early Pregnancy Signs
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-2 text-sm">
                <p className="text-muted-foreground">
                  Common early signs of pregnancy include:
                </p>
                <ul className="list-disc list-inside text-muted-foreground space-y-1 ml-2">
                  <li>Missed period</li>
                  <li>Nausea or morning sickness</li>
                  <li>Breast tenderness or swelling</li>
                  <li>Fatigue or tiredness</li>
                  <li>Frequent urination</li>
                  <li>Mood changes</li>
                  <li>Light spotting (implantation bleeding)</li>
                  <li>Food aversions or cravings</li>
                </ul>
                <div className="p-3 bg-muted rounded-md mt-3">
                  <p className="text-xs">
                    Take a pregnancy test 1-2 weeks after a missed period for most accurate results.
                  </p>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="resources">
            <AccordionTrigger data-testid="accordion-resources">
              Helpful Resources
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-2 text-sm">
                <p className="text-muted-foreground mb-2">
                  Find support and information:
                </p>
                <div className="space-y-2">
                  <a
                    href="#"
                    className="flex items-center gap-2 p-3 rounded-md hover-elevate border"
                    data-testid="link-resource-1"
                  >
                    <span className="flex-1">Planned Parenthood</span>
                    <ExternalLink className="w-4 h-4 text-muted-foreground" />
                  </a>
                  <a
                    href="#"
                    className="flex items-center gap-2 p-3 rounded-md hover-elevate border"
                    data-testid="link-resource-2"
                  >
                    <span className="flex-1">Local Sexual Health Clinics</span>
                    <ExternalLink className="w-4 h-4 text-muted-foreground" />
                  </a>
                  <a
                    href="#"
                    className="flex items-center gap-2 p-3 rounded-md hover-elevate border"
                    data-testid="link-resource-3"
                  >
                    <span className="flex-1">Emergency Contraception Locator</span>
                    <ExternalLink className="w-4 h-4 text-muted-foreground" />
                  </a>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );
}
