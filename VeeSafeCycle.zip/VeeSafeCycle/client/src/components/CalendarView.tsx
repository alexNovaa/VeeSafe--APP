import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar as CalendarIcon } from "lucide-react";

interface CalendarDay {
  date: Date;
  dayNumber: number;
  isPeriod: boolean;
  isFertile: boolean;
  isOvulation: boolean;
  isToday: boolean;
  isCurrentMonth: boolean;
}

interface CalendarViewProps {
  days: CalendarDay[];
  currentMonth: string;
}

export default function CalendarView({ days, currentMonth }: CalendarViewProps) {
  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const getDayStyle = (day: CalendarDay) => {
    if (!day.isCurrentMonth) {
      return "text-muted-foreground/40";
    }
    if (day.isOvulation) {
      return "bg-destructive text-destructive-foreground font-semibold";
    }
    if (day.isPeriod) {
      return "bg-primary text-primary-foreground";
    }
    if (day.isFertile) {
      return "bg-chart-3/20 text-foreground font-medium";
    }
    if (day.isToday) {
      return "border-2 border-primary font-semibold";
    }
    return "";
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <CalendarIcon className="w-5 h-5 text-primary" />
          <CardTitle>Cycle Calendar</CardTitle>
        </div>
        <CardDescription>{currentMonth}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-7 gap-1">
          {weekDays.map((day) => (
            <div
              key={day}
              className="text-center text-xs font-medium text-muted-foreground py-2"
            >
              {day}
            </div>
          ))}
          {days.map((day, index) => (
            <div
              key={index}
              className={`
                aspect-square flex items-center justify-center text-sm rounded-md
                ${getDayStyle(day)}
                ${day.isCurrentMonth ? 'hover-elevate cursor-pointer' : ''}
              `}
              data-testid={`calendar-day-${day.dayNumber}`}
            >
              {day.dayNumber}
            </div>
          ))}
        </div>

        <div className="flex flex-wrap gap-2 pt-2 border-t">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-primary"></div>
            <span className="text-xs text-muted-foreground">Period</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-chart-3/20 border border-chart-3"></div>
            <span className="text-xs text-muted-foreground">Fertile Window</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-destructive"></div>
            <span className="text-xs text-muted-foreground">Ovulation</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded border-2 border-primary"></div>
            <span className="text-xs text-muted-foreground">Today</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
