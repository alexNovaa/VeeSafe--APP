import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface AnonymousIdCardProps {
  userId: string;
}

export default function AnonymousIdCard({ userId }: AnonymousIdCardProps) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const handleCopy = () => {
    navigator.clipboard.writeText(userId);
    setCopied(true);
    toast({
      title: "ID Copied",
      description: "Your anonymous ID has been copied to clipboard",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-2">
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-muted-foreground" />
          <CardTitle className="text-base">Your Anonymous ID</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-2">
          <code className="flex-1 text-sm font-mono bg-muted px-3 py-2 rounded-md" data-testid="text-anonymous-id">
            {userId}
          </code>
          <Button
            size="icon"
            variant="ghost"
            onClick={handleCopy}
            data-testid="button-copy-id"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          </Button>
        </div>
        <CardDescription className="mt-2 text-xs">
          Save this ID to access your data later. We don't collect any personal information.
        </CardDescription>
      </CardContent>
    </Card>
  );
}
