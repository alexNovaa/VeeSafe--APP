import { Shield } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Header() {
  return (
    <header className="border-b bg-background sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-9 h-9 rounded-md bg-primary text-primary-foreground">
              <Shield className="w-5 h-5" />
            </div>
            <span className="text-xl font-semibold">VeeSafe</span>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" data-testid="button-help">
              Help
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
