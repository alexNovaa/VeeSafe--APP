import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Activity } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const symptomCategories = {
  physical: [
    { id: "breast-tenderness", label: "Breast tenderness" },
    { id: "cramping", label: "Cramping" },
    { id: "bloating", label: "Bloating" },
    { id: "headache", label: "Headache" },
    { id: "fatigue", label: "Fatigue" },
    { id: "nausea", label: "Nausea" },
  ],
  mood: [
    { id: "mood-swings", label: "Mood swings" },
    { id: "irritability", label: "Irritability" },
    { id: "anxiety", label: "Anxiety" },
    { id: "low-mood", label: "Low mood" },
  ],
  other: [
    { id: "spotting", label: "Spotting" },
    { id: "increased-appetite", label: "Increased appetite" },
    { id: "insomnia", label: "Insomnia" },
    { id: "acne", label: "Acne" },
  ],
};

export default function SymptomTracker() {
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const { toast } = useToast();

  const toggleSymptom = (symptomId: string) => {
    setSelectedSymptoms(prev =>
      prev.includes(symptomId)
        ? prev.filter(id => id !== symptomId)
        : [...prev, symptomId]
    );
  };

  const handleSave = () => {
    console.log('Symptoms logged:', selectedSymptoms);
    toast({
      title: "Symptoms Logged",
      description: `Recorded ${selectedSymptoms.length} symptom${selectedSymptoms.length !== 1 ? 's' : ''} for today.`,
    });
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-primary" />
          <CardTitle>Track Your Symptoms</CardTitle>
        </div>
        <CardDescription>
          Log how you're feeling today
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-3">
            <h4 className="text-sm font-medium">Physical Symptoms</h4>
            <div className="grid grid-cols-2 gap-3">
              {symptomCategories.physical.map((symptom) => (
                <div key={symptom.id} className="flex items-center gap-2">
                  <Checkbox
                    id={symptom.id}
                    checked={selectedSymptoms.includes(symptom.id)}
                    onCheckedChange={() => toggleSymptom(symptom.id)}
                    data-testid={`checkbox-${symptom.id}`}
                  />
                  <label
                    htmlFor={symptom.id}
                    className="text-sm cursor-pointer"
                  >
                    {symptom.label}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="text-sm font-medium">Mood & Mental</h4>
            <div className="grid grid-cols-2 gap-3">
              {symptomCategories.mood.map((symptom) => (
                <div key={symptom.id} className="flex items-center gap-2">
                  <Checkbox
                    id={symptom.id}
                    checked={selectedSymptoms.includes(symptom.id)}
                    onCheckedChange={() => toggleSymptom(symptom.id)}
                    data-testid={`checkbox-${symptom.id}`}
                  />
                  <label
                    htmlFor={symptom.id}
                    className="text-sm cursor-pointer"
                  >
                    {symptom.label}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="text-sm font-medium">Other</h4>
            <div className="grid grid-cols-2 gap-3">
              {symptomCategories.other.map((symptom) => (
                <div key={symptom.id} className="flex items-center gap-2">
                  <Checkbox
                    id={symptom.id}
                    checked={selectedSymptoms.includes(symptom.id)}
                    onCheckedChange={() => toggleSymptom(symptom.id)}
                    data-testid={`checkbox-${symptom.id}`}
                  />
                  <label
                    htmlFor={symptom.id}
                    className="text-sm cursor-pointer"
                  >
                    {symptom.label}
                  </label>
                </div>
              ))}
            </div>
          </div>
        </div>

        <Button 
          onClick={handleSave} 
          className="w-full"
          data-testid="button-save-symptoms"
        >
          Save Symptoms
        </Button>
      </CardContent>
    </Card>
  );
}
