import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, AlertTriangle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface SafeDaysDisplayProps {
  isSafePeriod: boolean;
  daysUntilFertileWindow: number;
  nextPeriodDate: string;
}

export default function SafeDaysDisplay({
  isSafePeriod,
  daysUntilFertileWindow,
  nextPeriodDate,
}: SafeDaysDisplayProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-primary" />
            <CardTitle>Safe Period Status</CardTitle>
          </div>
          {isSafePeriod ? (
            <Badge className="bg-chart-4 text-primary-foreground" data-testid="badge-safe-period">
              Lower Risk
            </Badge>
          ) : (
            <Badge variant="destructive" data-testid="badge-fertile-period">
              Fertile Period
            </Badge>
          )}
        </div>
        <CardDescription>
          Based on your current cycle phase
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {isSafePeriod ? (
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-4 bg-chart-4/10 rounded-md border border-chart-4/20">
              <Shield className="w-5 h-5 text-chart-4 mt-0.5 flex-shrink-0" />
              <div className="space-y-1">
                <p className="text-sm font-medium">Currently in Lower Risk Period</p>
                <p className="text-sm text-muted-foreground">
                  You are outside your fertile window. However, no day is 100% safe.
                </p>
              </div>
            </div>
            
            {daysUntilFertileWindow > 0 && (
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Fertile window starts in</p>
                <p className="text-2xl font-bold" data-testid="text-days-until-fertile">
                  {daysUntilFertileWindow} days
                </p>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-4 bg-destructive/10 rounded-md border border-destructive/20">
              <AlertTriangle className="w-5 h-5 text-destructive mt-0.5 flex-shrink-0" />
              <div className="space-y-1">
                <p className="text-sm font-medium">Currently in Fertile Period</p>
                <p className="text-sm text-muted-foreground">
                  You are in your fertile window. Pregnancy is most likely during this time.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="pt-3 border-t space-y-2">
          <p className="text-sm text-muted-foreground">Next Period Expected</p>
          <p className="text-lg font-semibold" data-testid="text-next-period-date">
            {new Date(nextPeriodDate).toLocaleDateString('en-US', { 
              month: 'long', 
              day: 'numeric',
              year: 'numeric' 
            })}
          </p>
        </div>

        <div className="flex items-start gap-2 p-3 bg-muted rounded-md">
          <AlertTriangle className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
          <p className="text-xs text-muted-foreground">
            <strong>Important:</strong> Cycle tracking is not a reliable contraceptive method. 
            Always use protection to prevent pregnancy and STIs.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
