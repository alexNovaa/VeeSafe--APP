import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Heart, Calendar, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface OvulationPredictionProps {
  nextOvulationDate: string;
  daysUntilOvulation: number;
  currentCycleDay: number;
  cycleLength: number;
  fertileWindowStart: string;
  fertileWindowEnd: string;
}

export default function OvulationPrediction({
  nextOvulationDate,
  daysUntilOvulation,
  currentCycleDay,
  cycleLength,
  fertileWindowStart,
  fertileWindowEnd,
}: OvulationPredictionProps) {
  const progressPercentage = (currentCycleDay / cycleLength) * 100;
  
  const getFertilityStatus = () => {
    if (daysUntilOvulation <= 0 && daysUntilOvulation >= -1) {
      return { label: "Peak Fertility", color: "bg-destructive text-destructive-foreground" };
    } else if (daysUntilOvulation > 0 && daysUntilOvulation <= 5) {
      return { label: "High Fertility", color: "bg-chart-3 text-primary-foreground" };
    } else if (daysUntilOvulation > 5 && daysUntilOvulation <= 10) {
      return { label: "Approaching Fertile Window", color: "bg-chart-4 text-primary-foreground" };
    }
    return { label: "Low Fertility", color: "bg-muted text-muted-foreground" };
  };

  const status = getFertilityStatus();

  return (
    <Card className="border-primary/20">
      <CardHeader>
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-primary" />
            <CardTitle>Ovulation Prediction</CardTitle>
          </div>
          <Badge className={status.color} data-testid="badge-fertility-status">
            {status.label}
          </Badge>
        </div>
        <CardDescription>
          Based on your cycle data
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="text-center space-y-2">
          <div className="text-5xl font-bold text-primary" data-testid="text-days-until-ovulation">
            {daysUntilOvulation > 0 ? daysUntilOvulation : 'Today'}
          </div>
          <p className="text-sm text-muted-foreground">
            {daysUntilOvulation > 0 ? 'days until ovulation' : daysUntilOvulation === 0 ? 'Ovulation Day' : 'Ovulation passed'}
          </p>
          <p className="text-sm font-medium" data-testid="text-ovulation-date">
            Expected: {new Date(nextOvulationDate).toLocaleDateString('en-US', { 
              month: 'long', 
              day: 'numeric',
              year: 'numeric' 
            })}
          </p>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Cycle Progress</span>
            <span className="font-medium" data-testid="text-cycle-day">Day {currentCycleDay} of {cycleLength}</span>
          </div>
          <Progress value={progressPercentage} className="h-2" />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Fertile Window Starts</p>
            <p className="text-sm font-medium" data-testid="text-fertile-window-start">
              {new Date(fertileWindowStart).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            </p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Fertile Window Ends</p>
            <p className="text-sm font-medium" data-testid="text-fertile-window-end">
              {new Date(fertileWindowEnd).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            </p>
          </div>
        </div>

        <div className="flex items-start gap-2 p-3 bg-muted rounded-md">
          <AlertCircle className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
          <p className="text-xs text-muted-foreground">
            Predictions are estimates based on your cycle data. Actual ovulation may vary.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
