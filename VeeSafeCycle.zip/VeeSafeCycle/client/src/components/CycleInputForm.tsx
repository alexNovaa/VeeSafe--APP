import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CycleInputFormProps {
  onSubmit?: (data: CycleFormData) => void;
  initialData?: CycleFormData;
}

export interface CycleFormData {
  lastPeriodDate: string;
  cycleLength: number;
  periodDuration: number;
}

export default function CycleInputForm({ onSubmit, initialData }: CycleInputFormProps) {
  const [formData, setFormData] = useState<CycleFormData>(
    initialData || {
      lastPeriodDate: "",
      cycleLength: 28,
      periodDuration: 5,
    }
  );
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Cycle data submitted:', formData);
    toast({
      title: "Cycle Data Saved",
      description: "Your cycle information has been updated successfully.",
    });
    onSubmit?.(formData);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-primary" />
          <CardTitle>Track Your Cycle</CardTitle>
        </div>
        <CardDescription>
          Enter your cycle information to get personalized predictions
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="lastPeriodDate">First Day of Last Period</Label>
            <Input
              id="lastPeriodDate"
              type="date"
              value={formData.lastPeriodDate}
              onChange={(e) => setFormData({ ...formData, lastPeriodDate: e.target.value })}
              required
              data-testid="input-last-period-date"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="cycleLength">Average Cycle Length (days)</Label>
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => setFormData({ ...formData, cycleLength: Math.max(21, formData.cycleLength - 1) })}
                data-testid="button-decrease-cycle-length"
              >
                -
              </Button>
              <Input
                id="cycleLength"
                type="number"
                min="21"
                max="35"
                value={formData.cycleLength}
                onChange={(e) => setFormData({ ...formData, cycleLength: parseInt(e.target.value) || 28 })}
                className="text-center"
                required
                data-testid="input-cycle-length"
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => setFormData({ ...formData, cycleLength: Math.min(35, formData.cycleLength + 1) })}
                data-testid="button-increase-cycle-length"
              >
                +
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">Typical range: 21-35 days</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="periodDuration">Period Duration (days)</Label>
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => setFormData({ ...formData, periodDuration: Math.max(2, formData.periodDuration - 1) })}
                data-testid="button-decrease-period-duration"
              >
                -
              </Button>
              <Input
                id="periodDuration"
                type="number"
                min="2"
                max="7"
                value={formData.periodDuration}
                onChange={(e) => setFormData({ ...formData, periodDuration: parseInt(e.target.value) || 5 })}
                className="text-center"
                required
                data-testid="input-period-duration"
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => setFormData({ ...formData, periodDuration: Math.min(7, formData.periodDuration + 1) })}
                data-testid="button-increase-period-duration"
              >
                +
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">Typical range: 2-7 days</p>
          </div>

          <Button type="submit" className="w-full" data-testid="button-save-cycle-data">
            Save Cycle Data
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
