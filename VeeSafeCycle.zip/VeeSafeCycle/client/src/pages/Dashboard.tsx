import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LogOut, Calendar as CalendarIcon } from "lucide-react";
import { addDays, differenceInDays, format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay } from "date-fns";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface CycleFormData {
  lastPeriodDate: string;
  cycleLength: number;
  periodDuration: number;
}

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: user, isLoading: userLoading } = useQuery<any>({
    queryKey: ["/api/auth/me"],
  });

  const { data: cycleDataFromServer } = useQuery({
    queryKey: ["/api/cycle-data"],
    enabled: !!user,
  });

  const [cycleData, setCycleData] = useState<CycleFormData | null>(null);
  const [showDataEntry, setShowDataEntry] = useState(false);

  useEffect(() => {
    if (cycleDataFromServer) {
      setCycleData(cycleDataFromServer as CycleFormData);
      setShowDataEntry(false);
    } else if (user && !showDataEntry) {
      setShowDataEntry(true);
    }
  }, [cycleDataFromServer, user]);

  useEffect(() => {
    if (!userLoading && !user) {
      setLocation("/");
    }
  }, [user, userLoading, setLocation]);

  const handleSaveCycleData = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cycleData) return;

    try {
      const response = await apiRequest("POST", "/api/cycle-data", cycleData);
      const savedData = await response.json();
      setCycleData(savedData);
      queryClient.invalidateQueries({ queryKey: ["/api/cycle-data"] });
      setShowDataEntry(false);
      toast({
        title: "Data saved",
        description: "Your cycle data has been updated",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save cycle data",
        variant: "destructive",
      });
    }
  };

  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout");
      queryClient.clear();
      setLocation("/");
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  const calculateCycleInfo = () => {
    if (!cycleData || !cycleData.lastPeriodDate) {
      return null;
    }

    const lastPeriod = new Date(cycleData.lastPeriodDate);
    const today = new Date();
    const currentCycleDay = differenceInDays(today, lastPeriod) + 1;
    
    const ovulationDay = cycleData.cycleLength - 14;
    const nextOvulation = addDays(lastPeriod, ovulationDay);
    const daysUntilOvulation = differenceInDays(nextOvulation, today);
    
    const fertileWindowStart = addDays(nextOvulation, -5);
    const fertileWindowEnd = addDays(nextOvulation, 1);
    
    const nextPeriod = addDays(lastPeriod, cycleData.cycleLength);

    const monthStart = startOfMonth(today);
    const monthEnd = endOfMonth(today);
    const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });
    
    const firstDayOfWeek = monthStart.getDay();
    const prevMonthDays = [];
    for (let i = firstDayOfWeek - 1; i >= 0; i--) {
      prevMonthDays.push(addDays(monthStart, -i - 1));
    }
    
    const allDays = [...prevMonthDays, ...daysInMonth];
    
    const calendarDays = allDays.map(date => {
      const isPeriod = date >= lastPeriod && date < addDays(lastPeriod, cycleData.periodDuration);
      const isFertile = date >= fertileWindowStart && date <= fertileWindowEnd;
      const isOvulation = isSameDay(date, nextOvulation);
      
      return {
        date,
        dayNumber: date.getDate(),
        isPeriod,
        isFertile,
        isOvulation,
        isToday: isSameDay(date, today),
        isCurrentMonth: date >= monthStart && date <= monthEnd,
      };
    });

    return {
      currentCycleDay: Math.max(1, currentCycleDay),
      nextOvulation: format(nextOvulation, 'MMM d'),
      daysUntilOvulation,
      nextPeriod: format(nextPeriod, 'MMM d'),
      calendarDays,
      currentMonth: format(today, 'MMMM yyyy'),
    };
  };

  const cycleInfo = calculateCycleInfo();

  if (userLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const weekDays = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8 pb-4 border-b">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-foreground rounded-sm"></div>
            <h1 className="text-2xl font-bold">VeeSafe</h1>
          </div>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={handleLogout}
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4" />
          </Button>
        </div>

        {showDataEntry || !cycleInfo ? (
          <div className="max-w-md mx-auto">
            <div className="mb-6 text-center">
              <h2 className="text-xl font-semibold mb-2">Enter Cycle Data</h2>
              <p className="text-sm text-muted-foreground">Provide your cycle information to see your calendar</p>
            </div>
            <form onSubmit={handleSaveCycleData} className="space-y-6 border rounded-md p-6">
              <div className="space-y-2">
                <Label htmlFor="lastPeriodDate" className="text-sm font-medium">Last Period Start Date</Label>
                <Input
                  id="lastPeriodDate"
                  type="date"
                  value={cycleData?.lastPeriodDate || ""}
                  onChange={(e) => setCycleData({ ...cycleData!, lastPeriodDate: e.target.value })}
                  required
                  data-testid="input-last-period-date"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cycleLength" className="text-sm font-medium">Cycle Length (days)</Label>
                <Input
                  id="cycleLength"
                  type="number"
                  min="21"
                  max="35"
                  value={cycleData?.cycleLength || 28}
                  onChange={(e) => setCycleData({ ...cycleData!, cycleLength: parseInt(e.target.value) || 28 })}
                  required
                  data-testid="input-cycle-length"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="periodDuration" className="text-sm font-medium">Period Duration (days)</Label>
                <Input
                  id="periodDuration"
                  type="number"
                  min="2"
                  max="7"
                  value={cycleData?.periodDuration || 5}
                  onChange={(e) => setCycleData({ ...cycleData!, periodDuration: parseInt(e.target.value) || 5 })}
                  required
                  data-testid="input-period-duration"
                />
              </div>

              <Button type="submit" className="w-full" data-testid="button-save-cycle-data">
                Save & View Calendar
              </Button>
            </form>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Calendar */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <CalendarIcon className="w-5 h-5" />
                  {cycleInfo.currentMonth}
                </h2>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowDataEntry(true)}
                  data-testid="button-edit-data"
                >
                  Update Data
                </Button>
              </div>
              
              <div className="border rounded-md p-4">
                <div className="grid grid-cols-7 gap-2 mb-2">
                  {weekDays.map((day) => (
                    <div
                      key={day}
                      className="text-center text-xs font-semibold py-2"
                    >
                      {day}
                    </div>
                  ))}
                </div>
                
                <div className="grid grid-cols-7 gap-2">
                  {cycleInfo.calendarDays.map((day, index) => {
                    let bgColor = "bg-white";
                    let textColor = "text-foreground";
                    let borderColor = "";
                    
                    if (day.isOvulation) {
                      bgColor = "bg-primary";
                      textColor = "text-primary-foreground";
                    } else if (day.isPeriod) {
                      bgColor = "bg-primary";
                      textColor = "text-primary-foreground";
                    } else if (day.isFertile) {
                      bgColor = "bg-accent";
                      textColor = "text-accent-foreground";
                    }
                    
                    if (day.isToday) {
                      borderColor = "ring-2 ring-foreground";
                    }
                    
                    if (!day.isCurrentMonth) {
                      textColor = "text-muted-foreground/30";
                    }

                    return (
                      <div
                        key={index}
                        className={`
                          aspect-square flex items-center justify-center text-sm font-medium rounded-sm
                          ${bgColor} ${textColor} ${borderColor}
                          ${day.isCurrentMonth ? 'hover-elevate cursor-pointer' : ''}
                        `}
                        data-testid={`calendar-day-${day.dayNumber}`}
                      >
                        {day.dayNumber}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Legend & Info */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="border rounded-md p-4">
                <h3 className="text-sm font-semibold mb-3">Legend</h3>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-6 h-6 rounded-sm bg-primary"></div>
                    <span>Period / Ovulation</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-6 h-6 rounded-sm bg-accent"></div>
                    <span>Fertile Window</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-6 h-6 rounded-sm bg-white border-2 border-foreground"></div>
                    <span>Today</span>
                  </div>
                </div>
              </div>

              <div className="border rounded-md p-4">
                <h3 className="text-sm font-semibold mb-3">Key Dates</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Next Ovulation:</span>
                    <span className="font-medium">{cycleInfo.nextOvulation}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Days Until:</span>
                    <span className="font-medium">{cycleInfo.daysUntilOvulation > 0 ? cycleInfo.daysUntilOvulation : 'Today'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Next Period:</span>
                    <span className="font-medium">{cycleInfo.nextPeriod}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Privacy Note */}
            <div className="border rounded-md p-4 text-center">
              <p className="text-xs text-muted-foreground">
                All predictions are estimates. For medical advice, consult a healthcare professional.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
